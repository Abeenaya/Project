package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.accenture.adf.businesstier.dao.EventDAO;
import com.accenture.adf.businesstier.dao.VisitorDAO;
import com.accenture.adf.businesstier.entity.Event;
import com.accenture.adf.businesstier.entity.EventCoordinator;
import com.accenture.adf.businesstier.entity.Visitor;
import com.accenture.adf.exceptions.FERSGenericException;
import com.accenture.adf.helper.FERSDataConnection;

/**
 * Junit test class for EventDAO class
 * 
 */
public class TestEventDAO {

	private static Connection connection = null;
	private static PreparedStatement statement = null;
	private static ResultSet resultSet = null;
	private ArrayList<Object[]> showAllEvents;
	private EventDAO dao;
	private List<EventCoordinator> eventCoordinatorList;

	/**
	 * Sets up database connection before other methods are executed in this
	 * class
	 * 
	 * @throws Exception
	 */
	@BeforeClass
	public static void setUpDatabaseConnection() throws Exception {
		connection = FERSDataConnection.createConnection();
	}

	/**
	 * Closes the database connection after all the methods are executed
	 * 
	 * @throws Exception
	 */
	@AfterClass
	public static void tearDownDatabaseConnection() throws Exception {
		/**
		 * @TODO: Close connection object here  
		 */
	}

	/**
	 * Sets up the objects required in other methods
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		showAllEvents = new ArrayList<Object[]>();
		dao = new EventDAO();
	}

	/**
	 * Deallocate the resources after execution of method
	 * 
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null  
		 */
	}

	/**
	 * Positive test case to test the method showAllEvents
	 */
	@Test
	public void testShowAllEventsByname_Positive() {
		String eventname="Pavlova  - All World Tour";
	int	expected=1;
		try {
			showAllEvents=dao.showAllEvents(eventname);		}
		catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		int actual=showAllEvents.size();
		assertEquals(expected, actual);
	}
	@Ignore
	@Test
	public void testShowAllEvents_Positive() {
		/**
		 * @TODO: Call showAllEvents method and assert it for
		 * size of returned type list
		 */	
		try {
			showAllEvents=dao.showAllEvents();
			int actual=showAllEvents.size();
			assertEquals(8, actual);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Ignore
	@Test
	public void testShowAllEventsAsc_Positive() {
		/**
		 * @TODO: Call showAllEvents method and assert it for
		 * size of returned type list
		 */	
		try {
			showAllEvents=dao.showAllEventsAsc();
			int actual=showAllEvents.size();
			assertEquals(8, actual);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Ignore
	@Test
	public void testShowAllEventsDesc_Positive() {
		/**
		 * @TODO: Call showAllEvents method and assert it for
		 * size of returned type list
		 */	
		try {
			showAllEvents=dao.showAllEventsDesc();
			int actual=showAllEvents.size();
			assertEquals(8, actual);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Junit test case to test positive case for updateEventDeletions
	 */
	@Test
	public void testUpdateEventDeletions_Positive() {
		/**
		 * @TODO: Find out seats available for an event by opening a connection
		 * and calling the query SELECT SEATSAVAILABLE FROM EVENT WHERE EVENTID = ?
		 * Call the updateEventDeletions for eventId
		 * Again find out the seats available for this event
		 * testSeatsAvailableBefore should be 1 more then testSeatsAvailableAfter
		 */	
		
		try{
			connection = FERSDataConnection.createConnection();
			String query = "SELECT SEATSAVAILABLE FROM EVENTSESSION E1,EVENT E2 WHERE EVENTID = ?";
			statement = connection.prepareStatement(query);
			statement.setInt(1, 1001);
			
			resultSet=statement.executeQuery();
			int row = 0;
			while (resultSet.next()) {
				row = resultSet.getInt(1);
			}
			
			dao.updateEventDeletions(1001, 10001);
			
			assertEquals(row+1, 4003);
		
		} catch(SQLException e){
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * Negative test case for method updateEventDeletions
	 */
	@Test
	public void testUpdateEventDeletions_Negative() {
		/**
		 * @TODO: Call updateEventDeletions for incorrect eventid and it should
		 * throw an exception
		 */
		
		try{
			dao.updateEventDeletions(101, 10001);
			
		}catch(FERSGenericException e){
			assertEquals("Records not updated properly", e.getMessage());
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Positive test case for method updateEventNominations
	 */
	@Ignore
	@Test
	public void testUpdateEventNominations_Positive() {
		/**
		 * @TODO: Find out seats available for an event by opening a connection
		 * and calling the query SELECT SEATSAVAILABLE FROM EVENT WHERE EVENTID = ?
		 * Call the updateEventNominations for eventId
		 * Again find out the seats available for this event
		 * testSeatsAvailableBefore should be 1 less then testSeatsAvailableAfter
		 */	
		
		try {
			connection=FERSDataConnection.createConnection();
			String query1= "SELECT SEATSAVAILABLE FROM EVENTSESSION WHERE EVENTID = ?";
			statement=connection.prepareStatement(query1);
			statement.setInt(1,1001);
			resultSet=statement.executeQuery();
			int expected=0;
			while(resultSet.next())
			{
				expected=resultSet.getInt(1);
			}

			dao.updateEventNominations(1001, 10001);
			resultSet=statement.executeQuery();
			int actual=0;
			while(resultSet.next())
			{
				actual=resultSet.getInt(1);
			}
			assertEquals(expected, actual+1);
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * Negative test case for method updateEventNominations
	 */
	@Ignore
	@Test
	public void testUpdateEventNominations_Negative() {
		/**
		 * @TODO: Call updateEventNominations for incorrect eventid and it should
		 * throw an exception
		 */		
		try {
			connection=FERSDataConnection.createConnection();
			String query1= "SELECT SEATSAVAILABLE FROM EVENTSESSION WHERE EVENTID = ?";
			statement=connection.prepareStatement(query1);
			statement.setInt(1,1001);
			resultSet=statement.executeQuery();
			int expected=0;
			while(resultSet.next())
			{
				expected=resultSet.getInt(1);
			}

			dao.updateEventNominations(1002, 10001);
			resultSet=statement.executeQuery();
			int actual=0;
			while(resultSet.next())
			{
				actual=resultSet.getInt(1);
			}
			assertEquals(expected, actual+1);
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * Positive test case for method checkEventsofVisitor
	 */
	@Test
	public void testCheckEventsOfVisitor_Positive() {
		
		
		VisitorDAO visitorDAO = new VisitorDAO();
		try {
			Visitor visitor = visitorDAO.searchUser("bsmith","password");
			
			boolean actual=dao.checkEventsofVisitor(visitor, 1001, 10001);
			assertEquals(true, actual);
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Junit test case for getEventCoordinator
	 */
	@Test
	public void testGetEventCoordinator(){
		/**
		 * @TODO: Call getEventCoordinator method
		 * Assert the size of return type arraylist
		 */		
		try {
			eventCoordinatorList=dao.getEventCoordinator();
			int actual=eventCoordinatorList.size();
			int expected=5;
			assertEquals(expected, actual);
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}
	
	/**
	 * Junit test case for getEvent
	 */
	@Test
	public void testGetEvent(){
		/**
		 * @TODO: Call getEvent method 
		 * Assert the returned Event type with the passed value of event id
		 */		
		Event e = null;
		try {
			e = dao.getEvent(1001, 10001);
		
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		assertEquals("Tour", e.getEventtype());
	}	
	
	/**
	 * Junit test case for updateEvent
	 */
	@Test
	public void testInsertEvent(){
		/**
		 * @TODO: Create Event object by setting appropriate values
		 * Call insertEvent method by passing this event object
		 * Assert the status of return type of this insertEvent method
		 */		
		try {
			 Event e=new Event();
		          e.setEventid(1007);
		          e.setName("NFL");
		          e.setDescription("Music");
		          e.setPlace("tomorrowland");
		          e.setDuration("0900-0100");
		          e.setEventtype("concert");
		          int actual=dao.insertEvent(e);
			//int actual=eventCoordinatorList.size();
			int expected=0;
			assertEquals(expected, actual);
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
	
	/**
	 * Junit test case for updateEvent
	 */
	@Test
	public void testUpdateEvent(){
		/**
		 * @TODO: Fetch Event object by calling showAllEvents method
		 * Update the values of event object
		 * Call updateEvent method by passing this modified event as object
		 * Assert the status of return type of updateEvent method
		 */	
		Event event=new Event();
		Object[] object=null;
		try {
			
	
			showAllEvents=dao.showAllEvents("Rose Parade");		
			for(int i=0;i<showAllEvents.size();i++){
				object=showAllEvents.get(i);
			}
			event.setEventid(Integer.parseInt(object[0].toString()));
			event.setName("Rose Parade");
			event.setDescription("Floats,Music and More");
			event.setDuration("0900-1400");
			event.setEventtype("Tour");
			event.setPlace("Rose Garden");
			event.setSeatsavailable("4001");
			event.setSessionId(Integer.parseInt(object[7].toString()));
			int actual=dao.updateEvent(event);
			int expected=1;
			assertEquals(expected, actual);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
				e.printStackTrace();
		} catch (FERSGenericException e) {
			e.printStackTrace();
		}
	
	}
	
	/**
	 * Junit test case for deleteEvent
	 */
	@Test
	public void testDeleteEvent(){
		/**
		 * @TODO: Fetch Event object by calling showAllEvents method		 * 
		 * Call deleteEvent method by passing this event id and event session id as object
		 * Assert the status of return type of updateEvent method
		 */	
		try
		{
			//ArrayList<Object[]> eventList = new ArrayList<Object[]>();
			showAllEvents = dao.showAllEvents("Fireworks Show");
			Object[] object=null;
			
			System.out.println(showAllEvents.size());
			for(int i=0;i<showAllEvents.size();i++){
				object=showAllEvents.get(i);
			}
			
			int eventId = Integer.parseInt(object[0].toString());
			int sessionId = Integer.parseInt(object[7].toString());
						
			int status = dao.deleteEvent(eventId, sessionId);
			assertEquals(1, status);
		}
	catch(Exception e)
	{
		e.printStackTrace();
	}

	}


	}


