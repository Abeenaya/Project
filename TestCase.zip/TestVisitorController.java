package com.accenture.adf.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.adf.businesstier.controller.VisitorController;
import com.accenture.adf.businesstier.dao.VisitorDAO;
import com.accenture.adf.businesstier.entity.Visitor;

/**
 * Junit test case to test the class VisitorController
 * 
 */
public class TestVisitorController {

	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	private ModelAndView modelAndView;
	private VisitorController controller;
	private VisitorDAO visitorDao;
	private Visitor visitor;

	/**
	 * Set up initial methods required before execution of every method
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		modelAndView = new ModelAndView();
		controller = new VisitorController();
		session = new MockHttpSession();
		response = new MockHttpServletResponse();
		visitorDao = new VisitorDAO();
	}

	/**
	 * Deallocate objects after execution of every method
	 * 
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		/**
		 * @TODO: Release all the objects here by assigning them null  
		 */
	}

	/**
	 * Positive test case to test the method newVisitor
	 */
	@Test
	public void testNewVisitor_Positive() {
		try {
			request = new MockHttpServletRequest("GET", "/newVistor.htm");

			request.setParameter("USERNAME", "ylee");
			request.setParameter("PASSWORD", "password");
			request.setParameter("FIRSTNAME", "TestVFname");
			request.setParameter("LASTNAME", "lname");
			request.setParameter("EMAIL", "mail");
			request.setParameter("PHONENO", "11111");
			request.setParameter("ADDRESS", "testAddress");
			modelAndView = controller.newVisitor(request, response);
		} catch (Exception exception) {
			fail("Exception");
		}
		assertEquals("/registration.jsp", modelAndView.getViewName());
	}

	/**
	 * Negative test case to test the method newVisitor
	 */
	@Test
	public void testNewVisitor_Negative() {
		/**
		 * @TODO: Call newVisitor method by passing request object as null and 
		 * asserting the model view name
		 */	
		try 
		{
			//request = new MockHttpServletRequest("GET", "/newVistor.htm");
			modelAndView = controller.newVisitor(null, response);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(null, modelAndView.getViewName());
	}

	/**
	 * Positive test case to test the method searchVisitor
	 */
	@Test
	public void testSearchVisitor_Positive() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set request parameters for USERNAME and PASSWORD for valid values
		 * Call searchVisitor method and assert model view name 
		 */	
		try {
			request = new MockHttpServletRequest("GET", "/searchVisitor.htm");
			request.setParameter("username","bsmith");
			request.setParameter("password","password");
			String user="bsmith";
			String pass="password";
			session=(MockHttpSession)request.getSession();
			session.setAttribute("USERNAME",user );
			session.setAttribute("PASSWORD", pass);
			
				modelAndView=controller.searchVisitor(request, response);
			} catch (Exception e) {
					e.printStackTrace();
			}
			assertEquals("/visitormain.jsp",modelAndView.getViewName());
	}

	/**
	 * Negative test case of invalid user for method searchVisitor
	 */
	@Test
	public void testSearchVisitor_Negative_InvalidUser() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set request parameters for USERNAME and PASSWORD for invalid values
		 * Call searchVisitor method and assert model view name 
		 */	
		try
		{
			request=new MockHttpServletRequest("GET","/searchVisitor.htm");
			request.setParameter("username","tejaswini");
			request.setParameter("password","teju");
			String user="tejaswini";
			String pass="teju";
			session=(MockHttpSession)request.getSession();
			session.setAttribute("username", user);
			session.setAttribute("password", pass);
			modelAndView=controller.searchVisitor(request, response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		assertEquals("/index.jsp", modelAndView.getViewName());
	}

	/**
	 * Negative test case for method searchVisitor
	 */
	@Test
	public void testSearchVisitor_Negative() {
		/**
		 * @TODO: Call searchVisitor method by passing request object as null and 
		 * asserting the model view name
		 */	
		try 
		{	
			request=null;
			modelAndView = controller.searchVisitor(request, response);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(null, modelAndView.getViewName());
	}

	/**
	 * Positive test case for method registerVisitor
	 */
	
	
	
@Ignore
	@Test
	public void testRegisterVisitor_Positive() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		 
		 * Set request parameters for USERNAME and PASSWORD for valid values
		 * Call registerVisitor method and assert model view name 
		 */
		
		try {
			request = new MockHttpServletRequest("GET", "/eventreg.htm");
			visitor=visitorDao.searchUser("npatel", "password");
			MockHttpSession session=(MockHttpSession) request.getSession();
			session.setAttribute("VISITOR", visitor);
			
			request.setParameter("eventId","1003");
			request.setParameter("sessionId", "10003");
			
			modelAndView = controller.registerVisitor(request, response);
							
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
		
			e.printStackTrace();
		}
		assertEquals("/visitormain.jsp", modelAndView.getViewName());
		
	}	

	
	
	
	/**
	 * Negative test case for method registerVisitor
	 * @throws Exception 
	 */
	@Ignore
	@Test
	public void testRegisterVisitor_Negative() throws Exception {
		/**
		 * @TODO: Call registerVisitor method by passing request object as null and 
		 * asserting the model view name
		 */	
		request=null;
		visitor=visitorDao.searchUser("npatel", "password");
		MockHttpSession session=(MockHttpSession) request.getSession();
		session.setAttribute("VISITOR", visitor);
		modelAndView = controller.registerVisitor(request, response);
		assertEquals("/visitormain.jsp", modelAndView.getViewName());
	}

	/**
	 * Positive test case for method updateVisitor
	 */
	@Test
	public void testUpdateVisitor_Positive() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		 
		 * Set request parameters for all valid user values
		 * Call updateVisitor method and assert model view name 
		 */
		Visitor visitor;
		try
		{
			request=new MockHttpServletRequest("GET","/updatevisitor.htm");
			request.setParameter("firstname", "Tejaswini");
			request.setParameter("lastname", "Mantur");
			request.setParameter("email", "t@gmail.com");
			request.setParameter("phoneno", "7896541586");
			request.setParameter("place", "jghkjgkg");
			
			
			request.setParameter("username", "bsmith");
			request.setParameter("password", "password");
			visitor=visitorDao.searchUser("bsmith", "password");
			
			session=(MockHttpSession) request.getSession();
			session.setAttribute("VISITOR", visitor);
			modelAndView = controller.updateVisitor(request, response);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		assertEquals("/updatevisitor.jsp",modelAndView.getViewName());
	}

	/**
	 * Negative test case for method updateVisitor
	 */
	@Test
	public void testUpdateVisitor_Negative() {
		/**
		 * @TODO: Call updateVisitor method by passing request object as null and 
		 * asserting the model view name
		 */	
		request=null;
		try {
			modelAndView=controller.updateVisitor(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(null, modelAndView.getViewName());
	
	}

	/**
	 * Positive test case for method unregisterEvent
	 * @throws Exception 
	 */
	@Ignore
	@Test
	public void testUnregisterEvent_Positive() throws Exception {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		 
		 * Set request parameters for all USERNAME, PASSWORD and eventId values
		 * Call unregisterEvent method and assert model view name 
		 */	
		
		request=new MockHttpServletRequest("GET","/eventunreg.htm");
		visitor=visitorDao.searchUser("npatel", "password");
		MockHttpSession session=(MockHttpSession) request.getSession();
		session.setAttribute("VISITOR", visitor);
		
	//	request.setParameter("name", "jjones");
		request.setParameter("eventId","1003");
		request.setParameter("eventsessionid", "10003");
		
		modelAndView = controller.unregisterEvent(request, response);
		assertEquals("/visitormain.jsp", modelAndView.getViewName());
	}

	/**
	 * Negative test case for method unregisterEvent
	 * @throws Exception 
	 */
	@Ignore
	@Test
	public void testUnregisterEvent_Negative() throws Exception {
		/**
		 * @TODO: Call unregisterEvent method by passing request object as null and 
		 * asserting the model view name
		 */	
		request=null;
		visitor=visitorDao.searchUser("npatel", "password");
		MockHttpSession session=(MockHttpSession) request.getSession();
		session.setAttribute("VISITOR", visitor);
		modelAndView = controller.registerVisitor(request, response);
		assertEquals("/visitormain.jsp", modelAndView.getViewName());
	}

	/**
	 * Positive test case for search events by name
	 */
	@Test
	public void testSearchEventsByName_Positive() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		 
		 * Set request parameters for eventname
		 * Call searchEventsByName method and assert model view name 
		 */		
		try {
			request = new MockHttpServletRequest("GET", "/searchEventByName.htm");
			Visitor v=visitorDao.searchUser("npatel", "password");
			session=(MockHttpSession) request.getSession();
			session.setAttribute("VISITOR", v);
			request.setParameter("eventname", "Rose Parade11");
			modelAndView = controller.searchEventsByName(request, response);
		} catch (Exception exception) {
			//fail("Exception");
			exception.printStackTrace();
		}
		assertEquals("/visitormain.jsp", modelAndView.getViewName());
	}

	/**
	 * Positive test case for search events by name catalog
	 */
	@Test
	public void testSearchEventsByNameCatalog_Positive() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		 
		 * Set request parameters for eventname
		 * Call searchEventsByNameCatalog method and assert model view name 
		 */	
		try {
			request = new MockHttpServletRequest("GET", "/searchEventByNameCatalog.htm");
			Visitor v=visitorDao.searchUser("npatel", "password");
			session=(MockHttpSession) request.getSession();
			session.setAttribute("VISITOR", v);
			request.setParameter("eventname", "Rose Parade11");
			modelAndView = controller.searchEventsByNameCatalog(request, response);
		} catch (Exception exception) {
			
			exception.printStackTrace();
		}
		assertEquals("/eventCatalog.jsp", modelAndView.getViewName());
	}

	/**
	 * Test case for show events in asc order
	 */
	@Test
	public void testShowEventsAsc() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		
		 * Call showEventsAsc method and assert model view name 
		 */		
		try {
			request = new MockHttpServletRequest("GET", "/displayasc.htm");
			Visitor v=visitorDao.searchUser("npatel", "password");
			session=(MockHttpSession) request.getSession();
			session.setAttribute("VISITOR", v);
			
			modelAndView = controller.showEventsAsc(request, response);
		} catch (Exception exception) {
			
			exception.printStackTrace();
		}
		assertEquals("/visitormain.jsp", modelAndView.getViewName());
	}

	/**
	 * Test case for show events in desc order
	 */
	@Test
	public void testShowEventsDesc() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		
		 * Call showEventsDesc method and assert model view name 
		 */		
		try {
			request = new MockHttpServletRequest("GET", "/displaydesc.htm");
			Visitor v=visitorDao.searchUser("npatel", "password");
			session=(MockHttpSession) request.getSession();
			session.setAttribute("VISITOR", v);
			
			modelAndView = controller.showEventsDesc(request, response);
		} catch (Exception exception) {
			
			exception.printStackTrace();
		}
		assertEquals("/visitormain.jsp", modelAndView.getViewName());
	}

	/**
	 * Test case for show events catalog asc order
	 */
	@Test
	public void testShowEventsCatalogAsc() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		
		 * Call showEventsCatalogAsc method and assert model view name 
		 */	
		try {
			request = new MockHttpServletRequest("GET", "/displaycatalogasc.htm");
			Visitor v=visitorDao.searchUser("npatel", "password");
			session=(MockHttpSession) request.getSession();
			session.setAttribute("VISITOR", v);
			
			modelAndView = controller.showEventsCatalogAsc(request, response);
		} catch (Exception exception) {
			
			exception.printStackTrace();
		}
		assertEquals("/eventCatalog.jsp", modelAndView.getViewName());
	}

	/**
	 * Test case for show events catalog desc
	 */
	@Test
	public void testShowEventsCatalogDesc() {
		/**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		
		 * Call showEventsCatalogDesc method and assert model view name 
		 */	
		try {
			request = new MockHttpServletRequest("GET", "/displaycatalogdesc.htm");
			Visitor v=visitorDao.searchUser("npatel", "password");
			session=(MockHttpSession) request.getSession();
			session.setAttribute("VISITOR", v);
			
			modelAndView = controller.showEventsCatalogDesc(request, response);
		} catch (Exception exception) {
			
			exception.printStackTrace();
		}
		assertEquals("/eventCatalog.jsp", modelAndView.getViewName());
	}

	/**
	 * Negative test case for search events by name
	 */
	@Ignore
	@Test
	public void testSearchEventsByName_Negative() {
		/**
		 * @TODO: Call searchEventsByName method by passing request object as null and 
		 * asserting the model view name
		 */		
		
		request=null;
		try {
			modelAndView=controller.searchEventsByName(request, response);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		assertEquals(null, modelAndView.getViewName());
	}

	/**
	 * Negative test case for search events by name catalog
	 */
	@Ignore
	@Test
	public void testSearchEventsByNameCatalog_Negative() {
		/**
		 * @TODO: Call searchEventsByNameCatalog method by passing request object as null and 
		 * asserting the model view name
		 */	
		request=null;
		try {
			modelAndView=controller.searchEventsByNameCatalog(request, response);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		//System.out.println(modelAndView);
		assertEquals(null, modelAndView.getViewName());
	}

	/**
	 * Negative test case for show events in asc order
	 */
	@Ignore
	@Test
	public void testShowEventsAsc_Negative() {
		/**
		 * @TODO: Call showEventsAsc method by passing request object as null and 
		 * asserting the model view name
		 */
		request=null;
		try {
			modelAndView=controller.showEventsAsc(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(null, modelAndView.getViewName());
	}

	/**
	 * Negative test case for show events in desc order
	 * 
	 */
	@Ignore
	@Test
	public void testShowEventsDesc_Negative() {
		/**
		 * @TODO: Call showEventsDesc method by passing request object as null and 
		 * asserting the model view name
		 */	
		request=null;
		try {
			modelAndView=controller.showEventsDesc(request, response);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		assertEquals(null, modelAndView.getViewName());
	}

	/**
	 * Negative test case for show events catalog in asc order
	 */
	@Ignore
	@Test
	public void testShowEventsCatalogAsc_Negative() {
		/**
		 * @TODO: Call showEventsCatalogAsc method by passing request object as null and 
		 * asserting the model view name
		 */	
		request=null;
		try {
			modelAndView=controller.showEventsCatalogAsc(request, response);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	
		assertEquals(null, modelAndView.getViewName());
	}

	/**
	 * Negative test case for show events catalog in desc order
	 */
	@Test
	public void testShowEventsCatalogDesc_Negative() {
		/**
		 * @TODO: Call showEventsCatalogDesc method by passing request object as null and 
		 * asserting the model view name
		 */		
		request=null;
		try {
			modelAndView=controller.showEventsCatalogDesc(request, response);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		assertEquals(null, modelAndView.getViewName());
	}
	
	
	/**
	 * Positive test case for change password
	 */
	/*@Test
	public void testChangePassword_Positive(){
		*//**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		 
		 * Set request parameters for password
		 * Call changePassword method and assert status as success
		 *//*		
	}
	
	*//**
	 * Negative test case for change password with password as null
	 *//*
	@Test
	public void testChangePassword_PasswordNull(){
		*//**
		 * @TODO: Create MockHttpServletRequest object 
		 * Set visitor object in VISITOR session by calling searchUser method from visitorDAO		 
		 * Do not set request parameters for password
		 * Call changePassword method and assert status as success
		 *//*	
	}
	
	*//**
	 * Negative test case for change password with visitor as null
	 *//*
	@Test
	public void testChangePassword_VisitorNull(){
		*//**
		 * @TODO: Create MockHttpServletRequest object 
		 * Do not set visitor object in VISITOR session by calling searchUser method from visitorDAO		 
		 * Set request parameters for password
		 * Call changePassword method and assert status as success
		 *//*		
	}*/
	
	/**
	 * Positive test case for change password
	 */
	@Test
	public void testChangePassword_Positive(){
		try{
			request = new MockHttpServletRequest("GET", "/changePWD.htm");
			Visitor visitor = visitorDao.searchUser("ylee", "password");	
			session.setAttribute("VISITOR", visitor);
			request.setSession(session);
			request.setParameter("password", "password3");
			modelAndView = controller.changePassword(request, response);		
		}catch(Exception exception){
			fail("Exception");
		}
		assertEquals("success", modelAndView.getModelMap().get("status"));
		request.setParameter("password", "password");
		modelAndView = controller.changePassword(request, response);
	}
	
	/**
	 * Negative test case for change password with password as null
	 */
	@Test
	public void testChangePassword_PasswordNull(){
		try{
			request = new MockHttpServletRequest("GET", "/changePWD.htm");
			Visitor visitor = visitorDao.searchUser("ylee", "password");			
			session.setAttribute("VISITOR", visitor);
			request.setSession(session);			
			modelAndView = controller.changePassword(request, response);		
		}catch(Exception exception){
			fail("Exception");
		}
		assertEquals("error", modelAndView.getModelMap().get("status"));
	}
	
	/**
	 * Negative test case for change password with visitor as null
	 */
	@Test
	public void testChangePassword_VisitorNull(){
		try{
			request = new MockHttpServletRequest("GET", "/changePWD.htm");
			Visitor visitor = new Visitor();			
			session.setAttribute("VISITOR", visitor);
			request.setSession(session);
			request.setParameter("password", "password");
			modelAndView = controller.changePassword(request, response);		
		}catch(Exception exception){
			fail("Exception");
		}
		assertEquals("error", modelAndView.getModelMap().get("status"));
	}
}
