package p1;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

public class EmployeeDAO {
	
	EntityManagerFactory emf;
	EntityManager em;
	public EntityManagerFactory getEmf() {
		return emf;
	}
	public void setEmf(EntityManagerFactory emf) {
		this.emf = emf;
	}
	public EntityManager getEm() {
		return em;
	}
	public void setEm(EntityManager em) {
		this.em = em;
	}
	
	@Transactional
	public List fetchEmployee()
	{
		em = emf.createEntityManager();
		Query q = em.createNamedQuery("a");
		List<Employee> e = q.getResultList();
		return e;
	}

}
