package p1;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.type.EmbeddedComponentType;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Resource rs = new ClassPathResource("config.xml");
		BeanFactory bf = new XmlBeanFactory(rs);
		
		EmployeeDAO ed = (EmployeeDAO)bf.getBean("empdao");
		List<Employee> e = ed.fetchEmployee();
		for (Employee employee : e) {
			System.out.println(employee.getId()+" "+employee.getName());
		}
		/*EntityManagerFactory emf = (EntityManagerFactory)bf.getBean("myentityManagerFactory");
		
		//EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
		EntityManager em = emf.createEntityManager();
		
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		
		Query q = em.createNamedQuery("a");
		
	//	q.executeUpdate();
				
		List<Employee> e = q.getResultList();
		
		for (Employee employee : e) {
			System.out.println(employee.getId()+" "+employee.getName());
		}*/
		/*Employee e = new Employee();
		e.setId(104);
		e.setName("rock");
		
		Address ad = new Address();
		ad.setId(13);
		ad.setStreetName("kamaraj st");
		ad.setCity("Chennai");
		
		e.setAd(ad);
		
		em.persist(e);*/
		//e = em.find(Employee.class, 102);
		
		//System.out.println(e.getName());
		
		/*et.commit();
		em.close();
		emf.close();*/
		
	}

}
